import { runPluginCommandWithTimeout } from "openclaw/plugin-sdk/sandbox";
import type { CliCommandResult, RunCli } from "./cli-adapter.js";

export const runCliCommand: RunCli = async (options): Promise<CliCommandResult> =>
  await runPluginCommandWithTimeout({
    argv: options.argv,
    timeoutMs: options.timeoutMs,
    cwd: options.cwd,
    env: options.env ?? process.env,
  });
