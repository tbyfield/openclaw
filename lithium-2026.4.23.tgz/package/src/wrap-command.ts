import { shellEscape } from "openclaw/plugin-sdk/sandbox";

export type WrapCommandParams = {
  command: string;
  workdir?: string;
  env?: Record<string, string>;
};

export function buildWrappedCommand(params: WrapCommandParams): string {
  const pieces: string[] = [];
  if (params.workdir) {
    pieces.push(`cd ${shellEscape(params.workdir)}`);
  }
  const envEntries = Object.entries(params.env ?? {}).filter(
    ([, value]) => value !== undefined,
  );
  envEntries.sort(([a], [b]) => a.localeCompare(b));
  for (const [key, value] of envEntries) {
    pieces.push(`export ${key}=${shellEscape(value)}`);
  }
  pieces.push(params.command);
  const joined = pieces.join(" && ");
  return `bash -lc ${shellEscape(joined)}`;
}

export function buildWrappedScript(params: {
  script: string;
  args?: string[];
}): string {
  const tokens = [
    "bash",
    "-lc",
    shellEscape(params.script),
    "openclaw-lithium-sh",
    ...(params.args ?? []).map((a) => shellEscape(a)),
  ];
  return tokens.join(" ");
}
