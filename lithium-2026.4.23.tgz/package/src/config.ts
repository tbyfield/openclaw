import { buildPluginConfigSchema, type OpenClawPluginConfigSchema } from "openclaw/plugin-sdk/core";
import {
  formatPluginConfigIssue,
  mapPluginConfigIssues,
} from "openclaw/plugin-sdk/extension-shared";
import { z } from "openclaw/plugin-sdk/zod";
import type { CliAdapterId } from "./cli-adapter.js";
import { LITHIUM_DEFAULT_BINARY } from "./lithium-adapter.js";
import { WXC_DEFAULT_BINARY } from "./wxc-adapter.js";

export type LithiumPluginConfig = {
  cli?: CliAdapterId;
  binaryPath?: string;
  image?: string;
  pool?: string;
  shape?: string;
  ports?: string[];
  extraCreateArgs?: string[];
  workdir?: string;
  wxcCapabilities?: string[];
  timeoutSeconds?: number;
};

export type ResolvedLithiumPluginConfig = {
  cli: CliAdapterId;
  binaryPath: string;
  image?: string;
  pool?: string;
  shape?: string;
  ports: string[];
  extraCreateArgs: string[];
  workdir: string;
  wxcCapabilities: string[];
  timeoutMs: number;
};

const DEFAULT_CLI: CliAdapterId = "lithium";
const DEFAULT_TIMEOUT_MS = 120_000;
const DEFAULT_WORKDIR = "/workspace";
const DEFAULT_WXC_CAPABILITIES: readonly string[] = ["permissiveLearningMode"];

function defaultBinaryForCli(cli: CliAdapterId): string {
  return cli === "wxc" ? WXC_DEFAULT_BINARY : LITHIUM_DEFAULT_BINARY;
}

const nonEmptyTrimmedString = (message: string) =>
  z.string({ error: message }).trim().min(1, { error: message });

const stringArray = (message: string) =>
  z.array(
    z.string({ error: message }).trim().min(1, { error: message }),
    { error: message },
  );

const LithiumPluginConfigSchema = z.strictObject({
  cli: z.enum(["lithium", "wxc"], { error: "cli must be one of lithium, wxc" }).optional(),
  binaryPath: nonEmptyTrimmedString("binaryPath must be a non-empty string").optional(),
  image: nonEmptyTrimmedString("image must be a non-empty string").optional(),
  pool: nonEmptyTrimmedString("pool must be a non-empty string").optional(),
  shape: nonEmptyTrimmedString("shape must be a non-empty string").optional(),
  ports: stringArray("ports must be an array of non-empty strings").optional(),
  extraCreateArgs: stringArray("extraCreateArgs must be an array of non-empty strings").optional(),
  workdir: nonEmptyTrimmedString("workdir must be a non-empty string").optional(),
  wxcCapabilities: stringArray(
    "wxcCapabilities must be an array of non-empty strings",
  ).optional(),
  timeoutSeconds: z
    .number({ error: "timeoutSeconds must be a number >= 1" })
    .min(1, { error: "timeoutSeconds must be a number >= 1" })
    .optional(),
});

export function createLithiumPluginConfigSchema(): OpenClawPluginConfigSchema {
  return buildPluginConfigSchema(LithiumPluginConfigSchema, {
    safeParse(value) {
      if (value === undefined) {
        return { success: true, data: undefined };
      }
      const parsed = LithiumPluginConfigSchema.safeParse(value);
      if (parsed.success) {
        return { success: true, data: parsed.data };
      }
      return {
        success: false,
        error: { issues: mapPluginConfigIssues(parsed.error.issues) },
      };
    },
  });
}

export function resolveLithiumPluginConfig(value: unknown): ResolvedLithiumPluginConfig {
  if (value === undefined) {
    return {
      cli: DEFAULT_CLI,
      binaryPath: defaultBinaryForCli(DEFAULT_CLI),
      image: undefined,
      pool: undefined,
      shape: undefined,
      ports: [],
      extraCreateArgs: [],
      workdir: DEFAULT_WORKDIR,
      wxcCapabilities: [...DEFAULT_WXC_CAPABILITIES],
      timeoutMs: DEFAULT_TIMEOUT_MS,
    };
  }

  const parsed = LithiumPluginConfigSchema.safeParse(value);
  if (!parsed.success) {
    const message = formatPluginConfigIssue(parsed.error.issues[0]);
    throw new Error(`Invalid lithium plugin config: ${message}`);
  }
  const cfg = parsed.data as LithiumPluginConfig;
  const cli = cfg.cli ?? DEFAULT_CLI;
  return {
    cli,
    binaryPath: cfg.binaryPath ?? defaultBinaryForCli(cli),
    image: cfg.image,
    pool: cfg.pool,
    shape: cfg.shape,
    ports: cfg.ports ?? [],
    extraCreateArgs: cfg.extraCreateArgs ?? [],
    workdir: cfg.workdir ?? DEFAULT_WORKDIR,
    wxcCapabilities: cfg.wxcCapabilities ?? [...DEFAULT_WXC_CAPABILITIES],
    timeoutMs:
      typeof cfg.timeoutSeconds === "number"
        ? Math.floor(cfg.timeoutSeconds * 1000)
        : DEFAULT_TIMEOUT_MS,
  };
}
