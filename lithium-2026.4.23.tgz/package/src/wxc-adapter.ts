import type {
  CliAdapter,
  CliExecParams,
  CliInspectResult,
  DestroyCtx,
  EnsureSandboxCtx,
  InspectCtx,
} from "./cli-adapter.js";

export const WXC_DEFAULT_BINARY = "wxc-exec";

// DEBUG(wxc-payload): hardcoded hello-world payload. Used to verify that
// the OpenClaw → wxc-exec plumbing is reaching the binary at all, before
// we worry about translating arbitrary agent commands into the correct
// wxc config schema. The decoded JSON shape is:
//   {
//     "version": "0.4.0-alpha",
//     "containerId": "CLI-HelloWorld",
//     "containment": "appcontainer",
//     "process": { "commandLine": "python -c \"...hello world...\"" },
//     "appContainer": { "capabilities": ["permissiveLearningMode"] }
//   }
// Once the round-trip works, replace this with a real builder that takes
// the wrapped command and capabilities and emits the same schema.
export const WXC_DEBUG_HARDCODED_PAYLOAD =
  "ewogICJ2ZXJzaW9uIjogIjAuNC4wLWFscGhhIiwKICAiY29udGFpbmVySWQiOiAiQ0xJLUhlbGxvV29ybGQiLAogICJjb250YWlubWVudCI6ICJhcHBjb250YWluZXIiLAogICJwcm9jZXNzIjogewogICAgImNvbW1hbmRMaW5lIjogInB5dGhvbiAtYyBcImltcG9ydCBzeXM7IHByaW50KCdIZWxsbyBmcm9tIFdYQyEnKTsgcHJpbnQoZidQeXRob24gdmVyc2lvbjoge3N5cy52ZXJzaW9ufScpOyBwcmludCgnU2NyaXB0IGV4ZWN1dGVkIHN1Y2Nlc3NmdWxseSBpbiBBcHBDb250YWluZXInKVwiIgogIH0sCiAgImFwcENvbnRhaW5lciI6IHsKICAgICJjYXBhYmlsaXRpZXMiOiBbInBlcm1pc3NpdmVMZWFybmluZ01vZGUiXQogIH0KfQ==";

export type WxcAdapterParams = {
  binaryPath: string;
  capabilities: string[];
};

export function buildWxcExecArgv(binaryPath: string): string[] {
  // DEBUG(wxc-payload): caller's wrappedCommand and configured capabilities are
  // currently ignored in favor of the hardcoded payload above.
  return [binaryPath, "--config-base64", WXC_DEBUG_HARDCODED_PAYLOAD];
}

// TODO(wxc-session-state): wxc-exec is one-shot; each invocation runs in a fresh
// sandbox, so state (cwd, shell history, installed packages) does not persist
// between agent commands in the same session. If session-state continuity is
// required, either (a) batch a session's commands into a single wxc-exec, or
// (b) teach wxc-exec to accept a session token and reuse the same sandbox.
export function createWxcCliAdapter(params: WxcAdapterParams): CliAdapter {
  const { binaryPath, capabilities } = params;

  return {
    id: "wxc",
    binaryPath,

    async ensureSandbox(ctx: EnsureSandboxCtx): Promise<{ runtimeId: string }> {
      // wxc hides the lifecycle behind exec. There's nothing to create up-front;
      // we return a synthetic runtimeId derived from the caller-supplied name so
      // OpenClaw's registry has a stable handle for the session.
      return { runtimeId: ctx.params.name };
    },

    execArgv(_params: CliExecParams): string[] {
      // DEBUG(wxc-payload): see WXC_DEBUG_HARDCODED_PAYLOAD above.
      void capabilities;
      return buildWxcExecArgv(binaryPath);
    },

    async inspect(_ctx: InspectCtx): Promise<CliInspectResult> {
      // wxc does not expose an inspect API. Reporting "running" keeps OpenClaw
      // from trying to recreate the sandbox; every exec is effectively fresh
      // anyway.
      return { exists: true, running: true };
    },

    async destroy(_ctx: DestroyCtx): Promise<void> {
      // Lifecycle is managed by wxc itself; nothing to tear down.
    },
  };
}
