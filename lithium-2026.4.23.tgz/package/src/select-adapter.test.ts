import { describe, expect, it, vi } from "vitest";
import type { RunCli } from "./cli-adapter.js";
import { createCliAdapterForConfig } from "./select-adapter.js";

describe("createCliAdapterForConfig", () => {
  it("returns the lithium adapter when cli=lithium and wires the binaryPath through", async () => {
    const adapter = createCliAdapterForConfig({
      cli: "lithium",
      binaryPath: "w365a",
      wxcCapabilities: [],
    });
    expect(adapter.id).toBe("lithium");
    expect(adapter.binaryPath).toBe("w365a");

    const run = vi.fn<Parameters<RunCli>, ReturnType<RunCli>>(async () => ({
      code: 0,
      stdout: "sbx-1",
      stderr: "",
    }));
    await adapter.ensureSandbox({
      params: { scopeKey: "s", name: "n" },
      run,
      timeoutMs: 1000,
    });
    expect(run.mock.calls[0]?.[0].argv[0]).toBe("w365a");
  });

  it("returns the wxc adapter when cli=wxc", () => {
    const adapter = createCliAdapterForConfig({
      cli: "wxc",
      binaryPath: "wxc-exec",
      wxcCapabilities: ["permissiveLearningMode"],
    });
    expect(adapter.id).toBe("wxc");
    expect(adapter.binaryPath).toBe("wxc-exec");
  });

  it("honors configured binaryPath overrides for both CLIs", () => {
    const a = createCliAdapterForConfig({
      cli: "lithium",
      binaryPath: "/opt/w365a",
      wxcCapabilities: [],
    });
    const b = createCliAdapterForConfig({
      cli: "wxc",
      binaryPath: "/opt/wxc-exec",
      wxcCapabilities: [],
    });
    expect(a.binaryPath).toBe("/opt/w365a");
    expect(b.binaryPath).toBe("/opt/wxc-exec");
  });

  // DEBUG(wxc-payload): wxc adapter currently emits a hardcoded hello-world
  // payload regardless of capabilities. Restore a capabilities-pass-through
  // assertion here once the dynamic payload builder is back.
  it("wxc adapter emits a `--config-base64` argv shape under the selector", () => {
    const adapter = createCliAdapterForConfig({
      cli: "wxc",
      binaryPath: "wxc-exec",
      wxcCapabilities: ["capOne", "capTwo"],
    });
    const argv = adapter.execArgv({ runtimeId: "x", wrappedCommand: "pwd" });
    expect(argv[0]).toBe("wxc-exec");
    expect(argv[1]).toBe("--config-base64");
    expect(typeof argv[2]).toBe("string");
  });
});
