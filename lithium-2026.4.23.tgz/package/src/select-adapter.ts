import type { CliAdapter } from "./cli-adapter.js";
import type { ResolvedLithiumPluginConfig } from "./config.js";
import { createLithiumCliAdapter } from "./lithium-adapter.js";
import { createWxcCliAdapter } from "./wxc-adapter.js";

export function createCliAdapterForConfig(
  config: Pick<ResolvedLithiumPluginConfig, "cli" | "binaryPath" | "wxcCapabilities">,
): CliAdapter {
  if (config.cli === "wxc") {
    return createWxcCliAdapter({
      binaryPath: config.binaryPath,
      capabilities: config.wxcCapabilities,
    });
  }
  return createLithiumCliAdapter({ binaryPath: config.binaryPath });
}
