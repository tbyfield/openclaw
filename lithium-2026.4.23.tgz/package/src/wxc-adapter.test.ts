import { describe, expect, it, vi } from "vitest";
import type { RunCli } from "./cli-adapter.js";
import { createWxcCliAdapter, WXC_DEBUG_HARDCODED_PAYLOAD } from "./wxc-adapter.js";

function decodeBase64Json(encoded: string): unknown {
  return JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
}

describe("createWxcCliAdapter", () => {
  it("has id='wxc' and exposes the configured binaryPath", () => {
    const adapter = createWxcCliAdapter({ binaryPath: "wxc-exec", capabilities: [] });
    expect(adapter.id).toBe("wxc");
    expect(adapter.binaryPath).toBe("wxc-exec");
  });

  it("ensureSandbox returns a synthetic runtimeId derived from params.name and does not invoke the CLI", async () => {
    const run = vi.fn<Parameters<RunCli>, ReturnType<RunCli>>(async () => ({
      code: 0,
      stdout: "",
      stderr: "",
    }));
    const adapter = createWxcCliAdapter({
      binaryPath: "wxc-exec",
      capabilities: ["permissiveLearningMode"],
    });
    const out = await adapter.ensureSandbox({
      params: { scopeKey: "s", name: "openclaw-synthetic-1" },
      run,
      timeoutMs: 5000,
    });
    expect(out).toEqual({ runtimeId: "openclaw-synthetic-1" });
    expect(run).not.toHaveBeenCalled();
  });

  // DEBUG(wxc-payload): execArgv currently returns a hardcoded hello-world
  // payload regardless of caller input. Tests below assert that contract
  // until we switch back to dynamic payload building.
  it("execArgv emits `wxc-exec --config-base64 <hardcoded>` ignoring wrappedCommand", () => {
    const adapter = createWxcCliAdapter({
      binaryPath: "wxc-exec",
      capabilities: ["permissiveLearningMode"],
    });
    const argv = adapter.execArgv({
      runtimeId: "ignored-by-wxc",
      wrappedCommand: `bash -lc 'echo hi'`,
    });
    expect(argv).toEqual(["wxc-exec", "--config-base64", WXC_DEBUG_HARDCODED_PAYLOAD]);
  });

  it("execArgv ignores the configured capabilities list while in debug-payload mode", () => {
    const a = createWxcCliAdapter({
      binaryPath: "wxc-exec",
      capabilities: ["capA", "capB"],
    });
    const b = createWxcCliAdapter({
      binaryPath: "wxc-exec",
      capabilities: [],
    });
    expect(a.execArgv({ runtimeId: "x", wrappedCommand: "pwd" })).toEqual(
      b.execArgv({ runtimeId: "x", wrappedCommand: "pwd" }),
    );
  });

  it("the hardcoded payload decodes to the expected hello-world JSON shape", () => {
    const decoded = decodeBase64Json(WXC_DEBUG_HARDCODED_PAYLOAD) as {
      version: string;
      containerId: string;
      containment: string;
      process: { commandLine: string };
      appContainer: { capabilities: string[] };
    };
    expect(decoded.version).toBe("0.4.0-alpha");
    expect(decoded.containerId).toBe("CLI-HelloWorld");
    expect(decoded.containment).toBe("appcontainer");
    expect(decoded.process.commandLine).toContain("Hello from WXC!");
    expect(decoded.appContainer.capabilities).toEqual(["permissiveLearningMode"]);
  });

  it("inspect reports running=true without invoking the CLI", async () => {
    const run = vi.fn<Parameters<RunCli>, ReturnType<RunCli>>(async () => ({
      code: 0,
      stdout: "",
      stderr: "",
    }));
    const adapter = createWxcCliAdapter({ binaryPath: "wxc-exec", capabilities: [] });
    const info = await adapter.inspect({ runtimeId: "x", run, timeoutMs: 1000 });
    expect(info).toEqual({ exists: true, running: true });
    expect(run).not.toHaveBeenCalled();
  });

  it("destroy resolves without invoking the CLI", async () => {
    const run = vi.fn<Parameters<RunCli>, ReturnType<RunCli>>(async () => ({
      code: 0,
      stdout: "",
      stderr: "",
    }));
    const adapter = createWxcCliAdapter({ binaryPath: "wxc-exec", capabilities: [] });
    await expect(
      adapter.destroy({ runtimeId: "x", run, timeoutMs: 1000 }),
    ).resolves.toBeUndefined();
    expect(run).not.toHaveBeenCalled();
  });
});
