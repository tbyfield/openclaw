import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { registerSandboxBackend } from "openclaw/plugin-sdk/sandbox";
import {
  createLithiumSandboxBackendFactory,
  createLithiumSandboxBackendManager,
} from "./src/backend.js";
import { createLithiumPluginConfigSchema, resolveLithiumPluginConfig } from "./src/config.js";

export default definePluginEntry({
  id: "lithium",
  name: "Lithium Sandbox",
  description: "Lithium-backed sandbox runtime for agent exec (lithium CLI, optional wxc wrapper).",
  configSchema: createLithiumPluginConfigSchema(),
  register(api) {
    if (api.registrationMode !== "full") {
      return;
    }
    const pluginConfig = resolveLithiumPluginConfig(api.pluginConfig);
    registerSandboxBackend("lithium", {
      factory: createLithiumSandboxBackendFactory({ pluginConfig }),
      manager: createLithiumSandboxBackendManager({ pluginConfig }),
    });
  },
});
